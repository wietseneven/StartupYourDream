<?
$db = [
	'host'      => 'localhost',
	'name'      => 'startupYourDream',
	'username'  => 'wnmm',
	'password'  => 'QXemMGVt7SfEp6rE'
];